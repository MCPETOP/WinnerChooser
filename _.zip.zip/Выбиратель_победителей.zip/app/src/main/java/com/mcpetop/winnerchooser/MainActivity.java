package com.mcpetop.winnerchooser;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
	public void rnd(View v){

		TextView vvv = (TextView) findViewById(R.id.text);
		EditText ed = (EditText) findViewById(R.id.count);
		
	int lol = Integer.valueOf(ed.getText().toString());
	
		
		vvv.setText("Победитель под номером : "+String.valueOf(Math.floor(Math.random() * lol)));
	

}}
